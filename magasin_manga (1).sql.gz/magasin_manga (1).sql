-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : ven. 21 jan. 2022 à 12:43
-- Version du serveur : 5.7.36
-- Version de PHP : 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `magasin_manga`
--

-- --------------------------------------------------------

--
-- Structure de la table `adresse`
--

DROP TABLE IF EXISTS `adresse`;
CREATE TABLE IF NOT EXISTS `adresse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_adresse` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `adresse`
--

INSERT INTO `adresse` (`id`, `nom_adresse`) VALUES
(1, '119 rue du mangaka, st-saitama.');

-- --------------------------------------------------------

--
-- Structure de la table `auteur`
--

DROP TABLE IF EXISTS `auteur`;
CREATE TABLE IF NOT EXISTS `auteur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prenom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `auteur`
--

INSERT INTO `auteur` (`id`, `nom`, `prenom`) VALUES
(1, 'Eiichiro', 'Oda');

-- --------------------------------------------------------

--
-- Structure de la table `doctrine_migration_versions`
--

DROP TABLE IF EXISTS `doctrine_migration_versions`;
CREATE TABLE IF NOT EXISTS `doctrine_migration_versions` (
  `version` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `doctrine_migration_versions`
--

INSERT INTO `doctrine_migration_versions` (`version`, `executed_at`, `execution_time`) VALUES
('DoctrineMigrations\\Version20211202073513', '2021-12-02 07:35:34', 54),
('DoctrineMigrations\\Version20211202074208', '2021-12-02 07:42:15', 94),
('DoctrineMigrations\\Version20211202091147', '2021-12-02 09:11:52', 98),
('DoctrineMigrations\\Version20211202102559', '2021-12-02 10:26:09', 100),
('DoctrineMigrations\\Version20220120125653', '2022-01-20 12:57:03', 382),
('DoctrineMigrations\\Version20220120161727', '2022-01-20 16:17:44', 570),
('DoctrineMigrations\\Version20220120164555', '2022-01-20 16:46:05', 34),
('DoctrineMigrations\\Version20220120164711', '2022-01-20 16:47:20', 112);

-- --------------------------------------------------------

--
-- Structure de la table `magasin`
--

DROP TABLE IF EXISTS `magasin`;
CREATE TABLE IF NOT EXISTS `magasin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `auteur` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adresse_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_54AF5F274DE7DC5C` (`adresse_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `magasin`
--

INSERT INTO `magasin` (`id`, `nom`, `auteur`, `adresse_id`) VALUES
(1, 'kakashop', 'eiichiro', 1);

-- --------------------------------------------------------

--
-- Structure de la table `manga`
--

DROP TABLE IF EXISTS `manga`;
CREATE TABLE IF NOT EXISTS `manga` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_manga` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tome` int(11) NOT NULL,
  `magasin_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_765A9E0320096AE3` (`magasin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `manga`
--

INSERT INTO `manga` (`id`, `nom_manga`, `tome`, `magasin_id`) VALUES
(1, 'One piece', 1, 1),
(2, 'boku no hero', 1, 1),
(3, 'one punch', 2, 1),
(4, 'hunter x hunter', 3, 1);

-- --------------------------------------------------------

--
-- Structure de la table `manga_auteur`
--

DROP TABLE IF EXISTS `manga_auteur`;
CREATE TABLE IF NOT EXISTS `manga_auteur` (
  `manga_id` int(11) NOT NULL,
  `auteur_id` int(11) NOT NULL,
  PRIMARY KEY (`manga_id`,`auteur_id`),
  KEY `IDX_D61A13477B6461` (`manga_id`),
  KEY `IDX_D61A134760BB6FE6` (`auteur_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `manga_auteur`
--

INSERT INTO `manga_auteur` (`manga_id`, `auteur_id`) VALUES
(1, 1),
(2, 1),
(4, 1);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` json NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `email`, `roles`, `password`) VALUES
(1, 'jamesraoul97400@gmail.com', '{\"role\": \"ROLE_ADMIN\"}', '$2y$13$2QYQL0QgnyAbXeM8aBQTXeVcF38zhTJb8TYd2buHrHHQKuDyg2.oO'),
(2, 'james@test.re', '{\"role\": \"ROLE_USER\"}', '$2y$13$uMcRiEmUa7zQhmBAqOAjTOmTJLgG.kP2X8l1tmPV1gIh7P3dVSKWS'),
(3, 'james@james.re', '{\"role\": \"ROLE_USER\"}', 'james'),
(4, 'mathieu@test.re', '[]', '$2y$13$083vWgVCXedn5zIwoIQ0hOFxnBKX9Jc3Bpi1NJ9MGBbWg/jUNiyhe'),
(5, 'mathieu@test.ree', '[]', '$2y$13$HKDOGxjdzF9.3MgdZkSyJ.OQgkgvvL/YUPFshokKJfIoMIhcuOnNy'),
(6, 'mathieu@test.reee', '[]', '$2y$13$G5Tj7xrlAhnoFA7.jyKrIOXuTzM5BM5eByypRG33LRMAZX.aEr6Hy'),
(7, 'james@test.ree', '[]', '$2y$13$cl3kTjyEf1ch9lVDOmkPwen/MHjrGCvSZQkggEml2gYlhNFBYgfbu');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `magasin`
--
ALTER TABLE `magasin`
  ADD CONSTRAINT `FK_54AF5F274DE7DC5C` FOREIGN KEY (`adresse_id`) REFERENCES `adresse` (`id`);

--
-- Contraintes pour la table `manga`
--
ALTER TABLE `manga`
  ADD CONSTRAINT `FK_765A9E0320096AE3` FOREIGN KEY (`magasin_id`) REFERENCES `magasin` (`id`);

--
-- Contraintes pour la table `manga_auteur`
--
ALTER TABLE `manga_auteur`
  ADD CONSTRAINT `FK_D61A134760BB6FE6` FOREIGN KEY (`auteur_id`) REFERENCES `auteur` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_D61A13477B6461` FOREIGN KEY (`manga_id`) REFERENCES `manga` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
